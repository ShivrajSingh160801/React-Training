import Server from './app/server/index'

const app = new Server();

app.start();

