export interface userSignup {
  name: string;
  email: string;
  password: string;
  phone: string;
}

export interface userSignin {
  email: string;
  password: string;
}

export interface supplier {
  supplier : string;
}
