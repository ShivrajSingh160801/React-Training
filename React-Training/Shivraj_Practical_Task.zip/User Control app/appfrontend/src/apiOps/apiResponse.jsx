export const successMessage = 'Users retrieved successfully';
export const errorMessage = 'Failed to retrieve users'; 