export interface customer {
  customername : string;
  orderqty : number;
  stockId : string;
}

export interface stock {
  stockname : string;
  quantity : number;
  stockordered:number
}
