export class responsemodel{
    public status : Number | undefined ;
    public data : any;
    public message : string | undefined;
}